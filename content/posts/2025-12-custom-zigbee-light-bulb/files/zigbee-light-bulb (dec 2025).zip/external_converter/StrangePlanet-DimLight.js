import * as m from 'zigbee-herdsman-converters/lib/modernExtend';

export default {
    zigbeeModel: ['DimLight'],
    model: 'DimLight',
    vendor: 'StrangePlanet',
    description: 'DimLight',
    extend: [
        m.light({
            effect: false,
            powerOnBehavior: false,
            colorTemp: {
                startup: false,
                range: [166, 555]
            },
        }),
    ],
};
