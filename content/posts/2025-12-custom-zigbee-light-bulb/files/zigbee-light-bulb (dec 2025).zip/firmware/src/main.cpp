#include <Arduino.h>
#include <Zigbee.h>
#include <FastLED.h>
#include "TempZigbeeColorDimmableLight.h"

#define TAG "light"

#define LED_PIN 0
#define NUM_LEDS 52

#define TEMP_AMBER 1800
#define TEMP_WARM 3000
#define TEMP_COLD 6000

// wait for release of https://github.com/espressif/arduino-esp32/pull/12094
auto light = TempZigbeeColorDimmableLight(10);

CRGB leds[NUM_LEDS];

void onboardLed(uint8_t red_val, uint8_t green_val, uint8_t blue_val)
{
    rgbLedWriteOrdered(RGB_BUILTIN, LED_COLOR_ORDER_GRB, red_val, green_val, blue_val);
}

void setLight(bool on, uint8_t level, uint16_t mireds)
{
    ESP_LOGI(TAG, "on=%i", on);
    ESP_LOGI(TAG, "level=%i", level);
    ESP_LOGI(TAG, "temp=%i", mireds);

    if (!on || level == 0)
    {
        FastLED.setBrightness(0);
        return;
    }

    // R = Amber
    // G = Warm White
    // B = Cold White
    CRGB color;

    uint16_t temp = constrain(1000000.0 / mireds, TEMP_AMBER, TEMP_COLD);

    if (temp <= TEMP_WARM)
    {
        // fade amber to warm
        auto factor = (uint8_t) map(temp, TEMP_AMBER, TEMP_WARM, 0, 255);
        color.r = 255 - factor;
        color.g = factor;
        color.b = 0;
    }
    else
    {
        // fade warm to cold
        auto factor = (uint8_t) map(temp, TEMP_WARM, TEMP_COLD, 0, 255);
        color.r = 0;
        color.g = 255 - factor;
        color.b = factor;
    }

    fill_solid(leds, NUM_LEDS, color);
    FastLED.setBrightness(level);
}

void setup()
{
    Serial.begin(115200);

    FastLED.addLeds<WS2812, LED_PIN, BRG>(leds, NUM_LEDS);
    FastLED.setCorrection(UncorrectedColor);

    setLight(false, 255, ESP_ZB_ZCL_COLOR_CONTROL_COLOR_TEMPERATURE_DEF_VALUE);

    onboardLed(255, 0, 0);

    light.setManufacturerAndModel("StrangePlanet", "DimLight");
    light.setLightColorCapabilities(ZIGBEE_COLOR_CAPABILITY_COLOR_TEMP);
    light.onLightChangeTemp(setLight);
    Zigbee.addEndpoint(&light);

    if (!Zigbee.begin())
    {
        ESP_LOGE(TAG, "Zigbee failed to start!");
        delay(1000);
        esp_restart();
    }
    else
    {
        ESP_LOGI(TAG, "Zigbee started successfully!");
    }

    bool ledOn = true;
    ESP_LOGI(TAG, "Connecting to network");
    while (!Zigbee.connected())
    {
        Serial.print(".");
        delay(100);

        ledOn = !ledOn;
        if (ledOn)
        {
            onboardLed(255, 0, 0);
        }
        else
        {
            onboardLed(0, 0, 0);
        }
    }
    Serial.println();
    ESP_LOGI(TAG, "Ready");

    onboardLed(0, 100, 0);

    delay(1000);

    onboardLed(0, 0, 0);
}

void loop()
{
    FastLED.show();
}
